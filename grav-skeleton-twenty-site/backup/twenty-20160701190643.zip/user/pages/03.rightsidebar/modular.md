---
title: Right Sidebar
subtitle: "Behold the <strong>Right Sidebar</strong>"
description: "Where things on the right ... accompany that on the left."
body_class: right-sidebar
header_class: skel-layers-fixed
icon: tablet
onpage_menu: true
content:
    items: @self.modular
    order:
        by: default
        dir: asc
        custom:
            - _content
---
