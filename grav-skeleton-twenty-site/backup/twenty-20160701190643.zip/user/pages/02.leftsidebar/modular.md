---
title: Left Sidebar
subtitle: "Behold the <strong>Left Sidebar</strong>"
description: "Where things on the left ... accompany that on the right."
body_class: left-sidebar
header_class: skel-layers-fixed
icon: laptop
onpage_menu: true
content:
    items: @self.modular
    order:
        by: default
        dir: asc
        custom:
            - _content
---
