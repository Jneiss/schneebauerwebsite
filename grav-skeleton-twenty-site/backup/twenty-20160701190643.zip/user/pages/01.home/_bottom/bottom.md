---
title: Ready to do <strong>something</strong>?
buttons:
    - text: Take My Money
      url: '#'
      class: special
    - text: LOL Wut
      url: '#'  
menu: after_article      
---
Proin a ullamcorper elit, et sagittis turpis integer ut fermentum.