---
title: "Behold the <strong>icons</strong> that visualize what you’re all about. or just take up space. your call bro."
buttons:
    - text: Find Out More
      url: '#'
icons:
    - label: Feature 1
      icon: clock-o
    - label: Feature 2
      icon: volume-up 
    - label: Feature 3
      icon: laptop  
    - label: Feature 4
      icon: inbox
    - label: Feature 5
      icon: lock   
    - label: Feature 6
      icon: cog       
---
Sed tristique purus vitae volutpat ultrices. Aliquam eu elit eget arcu comteger ut fermentum lorem. Lorem ipsum dolor sit amet. Sed tristique purus vitae volutpat ultrices. eu elit eget commodo. Sed tristique purus vitae volutpat ultrices. Aliquam eu elit eget arcu commodo.