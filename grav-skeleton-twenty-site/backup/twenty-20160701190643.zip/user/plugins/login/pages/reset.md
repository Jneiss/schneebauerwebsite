---
title: Reset password

form:
    fields:
        - name: username
          type: text
          id: username
          placeholder: Username
          readonly: true
        - name: password
          type: password
          id: password
          placeholder: Password
          autofocus: true
        - name: token
          type: hidden
---

# Password Reset