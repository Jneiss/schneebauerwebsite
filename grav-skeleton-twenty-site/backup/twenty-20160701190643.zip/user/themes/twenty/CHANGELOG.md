# v1.4.0
## 10/16/2015

1. [](#new)
    * Twenty codebase updated to latest release
    * Various fixes and improvements
    * Menu generated automatically from collection of pages

# v1.3.0
## 10/15/2015

1. [](#new)
    * Removed SimpleForm plugin support due to constant compatibility problems
    * Added support for Email and Form plugins

# v1.2.1
## 09/21/2015

1. [](#improved)
    * improved default layout
    * improved SimpleForm compatibility
    * improved Grav compatibility
    * minor fixes

# v1.1.1
## 09/04/2015

1. [](#improved)
    * reworked initialization

# v1.1.0
## 08/25/2015

1. [](#improved)
    * Added blueprints for Grav Admin plugin

# v1.0.0
## 03/24/2015

1. [](#new)
    * ChangeLog started...
