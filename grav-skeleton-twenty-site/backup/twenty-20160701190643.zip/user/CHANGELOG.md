# v1.1.0
## 10/16/2015

1. [](#new)
    * Files reorganization for major Twenty update

# v1.0.3
## 10/15/2015

1. [](#new)
    * Removed SimpleForm plugin support due to constant compatibility problems
    * Added support for Email and Form plugins

# v1.0.1
## 09/21/2015

1. [](#new)
    * added SimpleForm landing page

# v1.0.0
## 03/24/2015

1. [](#new)
    * ChangeLog started...
